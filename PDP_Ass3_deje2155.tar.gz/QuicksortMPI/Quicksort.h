#include "qsMPI.h"

