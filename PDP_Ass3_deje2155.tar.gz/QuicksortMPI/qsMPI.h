#include "qsAlgorithm.h"
#include <mpi.h>

int foo(int x);